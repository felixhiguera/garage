<?php
$server="localhost";
//$user = "root";
//$pass = "";
$user = "felix";
$pass = "felix123";
$bd = "id12430567_loginsystem";
//$bd = "loginsystem";
//webhost user felix pass felix123
?>